import type React from "react"
import type { Metadata } from "next"
import { Inter } from "next/font/google"
import "./globals.css"
import { Navigation } from "@/components/navigation"
import { CursorEffect } from "@/components/cursor-effect"
import { ParticleBackground } from "@/components/particle-background"
import { SoundToggle } from "@/components/sound-toggle"

const inter = Inter({ subsets: ["latin"] })

export const metadata: Metadata = {
  title: "EcoSwap - Swap. Save. Sustain.",
  description: "Sustainable item swapping platform for your community",
    generator: 'v0.dev'
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="en">
      <body className={`${inter.className} bg-gray-900 text-white min-h-screen`}>
        <div className="fixed inset-0 bg-gradient-to-br from-emerald-900/20 via-purple-900/20 to-blue-900/20 pointer-events-none" />
        <Navigation />
        <main className="relative z-10">{children}</main>
        <CursorEffect />
        <ParticleBackground />
        <SoundToggle />
      </body>
    </html>
  )
}
