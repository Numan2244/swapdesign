"use client"

import type React from "react"

import { useState } from "react"
import { Upload, Camera, X, Sparkles, Info } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"

const categories = [
  { id: "clothing", label: "Clothing", icon: "👕" },
  { id: "books", label: "Books", icon: "📚" },
  { id: "electronics", label: "Electronics", icon: "📱" },
  { id: "home", label: "Home & Garden", icon: "🏠" },
  { id: "sports", label: "Sports", icon: "⚽" },
  { id: "toys", label: "Toys & Games", icon: "🎮" },
]

const conditions = [
  { id: "new", label: "New", desc: "Never used, with tags/packaging" },
  { id: "like-new", label: "Like New", desc: "Barely used, excellent condition" },
  { id: "good", label: "Good", desc: "Used but well maintained" },
  { id: "used", label: "Used", desc: "Shows signs of wear but functional" },
  { id: "vintage", label: "Vintage", desc: "Older item with character" },
]

export default function PostItemPage() {
  const [formData, setFormData] = useState({
    title: "",
    description: "",
    category: "",
    condition: "",
    location: "",
    ecoFriendly: false,
  })
  const [images, setImages] = useState<string[]>([])
  const [dragActive, setDragActive] = useState(false)
  const [showEcoInfo, setShowEcoInfo] = useState(false)

  const handleInputChange = (field: string, value: string | boolean) => {
    setFormData((prev) => ({ ...prev, [field]: value }))
  }

  const handleImageUpload = (files: FileList | null) => {
    if (files) {
      const newImages = Array.from(files).map((file) => URL.createObjectURL(file))
      setImages((prev) => [...prev, ...newImages].slice(0, 5)) // Max 5 images
    }
  }

  const removeImage = (index: number) => {
    setImages((prev) => prev.filter((_, i) => i !== index))
  }

  const handleDrag = (e: React.DragEvent) => {
    e.preventDefault()
    e.stopPropagation()
    if (e.type === "dragenter" || e.type === "dragover") {
      setDragActive(true)
    } else if (e.type === "dragleave") {
      setDragActive(false)
    }
  }

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault()
    e.stopPropagation()
    setDragActive(false)

    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      handleImageUpload(e.dataTransfer.files)
    }
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    console.log("Form submitted:", formData, images)
    // Handle form submission
  }

  return (
    <div className="min-h-screen pt-20 pb-20 md:pb-8">
      <div className="container mx-auto px-4 max-w-4xl">
        {/* Header */}
        <div className="text-center mb-12">
          <h1 className="text-5xl font-bold gradient-text mb-4">Post an Item</h1>
          <p className="text-xl text-gray-300">Share something amazing with your community</p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-8">
          {/* Image Upload */}
          <div className="glass-strong rounded-2xl p-6">
            <h2 className="text-2xl font-semibold text-white mb-6">Add Photos</h2>

            <div
              className={`relative border-2 border-dashed rounded-xl p-8 text-center transition-all duration-300 ${
                dragActive
                  ? "border-emerald-400 bg-emerald-400/10 neon-glow"
                  : "border-gray-400 hover:border-emerald-400"
              }`}
              onDragEnter={handleDrag}
              onDragLeave={handleDrag}
              onDragOver={handleDrag}
              onDrop={handleDrop}
            >
              <input
                type="file"
                multiple
                accept="image/*"
                onChange={(e) => handleImageUpload(e.target.files)}
                className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
              />

              <Upload className="w-12 h-12 text-gray-400 mx-auto mb-4" />
              <p className="text-lg text-gray-300 mb-2">Drag & drop images here</p>
              <p className="text-sm text-gray-400 mb-4">or click to browse (max 5 images)</p>

              <Button type="button" variant="outline" className="border-emerald-400 text-emerald-400">
                <Camera className="w-4 h-4 mr-2" />
                Choose Files
              </Button>
            </div>

            {/* Image Preview */}
            {images.length > 0 && (
              <div className="mt-6 grid grid-cols-2 md:grid-cols-5 gap-4">
                {images.map((image, index) => (
                  <div key={index} className="relative group">
                    <img
                      src={image || "/placeholder.svg"}
                      alt={`Preview ${index + 1}`}
                      className="w-full h-24 object-cover rounded-lg"
                    />
                    <button
                      type="button"
                      onClick={() => removeImage(index)}
                      className="absolute -top-2 -right-2 w-6 h-6 bg-red-500 text-white rounded-full flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity duration-200"
                    >
                      <X className="w-4 h-4" />
                    </button>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Basic Information */}
          <div className="glass-strong rounded-2xl p-6">
            <h2 className="text-2xl font-semibold text-white mb-6">Item Details</h2>

            <div className="space-y-6">
              {/* Title */}
              <div className="space-y-2">
                <label className="block text-sm font-medium text-gray-300">Title *</label>
                <Input
                  value={formData.title}
                  onChange={(e) => handleInputChange("title", e.target.value)}
                  placeholder="What are you swapping?"
                  className="glass border-white/20 text-white placeholder-gray-400 focus:border-emerald-400 focus:neon-glow"
                  required
                />
              </div>

              {/* Description */}
              <div className="space-y-2">
                <label className="block text-sm font-medium text-gray-300">Description *</label>
                <Textarea
                  value={formData.description}
                  onChange={(e) => handleInputChange("description", e.target.value)}
                  placeholder="Describe your item in detail..."
                  rows={4}
                  className="glass border-white/20 text-white placeholder-gray-400 focus:border-emerald-400 focus:neon-glow resize-none"
                  required
                />
              </div>

              {/* Location */}
              <div className="space-y-2">
                <label className="block text-sm font-medium text-gray-300">Location *</label>
                <Input
                  value={formData.location}
                  onChange={(e) => handleInputChange("location", e.target.value)}
                  placeholder="Your area/neighborhood"
                  className="glass border-white/20 text-white placeholder-gray-400 focus:border-emerald-400 focus:neon-glow"
                  required
                />
              </div>
            </div>
          </div>

          {/* Category Selection */}
          <div className="glass-strong rounded-2xl p-6">
            <h2 className="text-2xl font-semibold text-white mb-6">Category</h2>

            <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
              {categories.map((category) => (
                <button
                  key={category.id}
                  type="button"
                  onClick={() => handleInputChange("category", category.id)}
                  className={`p-4 rounded-xl text-left transition-all duration-300 ${
                    formData.category === category.id
                      ? "eco-gradient text-white neon-glow"
                      : "glass border border-white/20 hover:border-emerald-400/50 hover:glass-strong"
                  }`}
                >
                  <div className="text-2xl mb-2">{category.icon}</div>
                  <div className="font-medium">{category.label}</div>
                </button>
              ))}
            </div>
          </div>

          {/* Condition Selection */}
          <div className="glass-strong rounded-2xl p-6">
            <h2 className="text-2xl font-semibold text-white mb-6">Condition</h2>

            <div className="space-y-3">
              {conditions.map((condition) => (
                <button
                  key={condition.id}
                  type="button"
                  onClick={() => handleInputChange("condition", condition.id)}
                  className={`w-full p-4 rounded-xl text-left transition-all duration-300 ${
                    formData.condition === condition.id
                      ? "eco-gradient text-white neon-glow"
                      : "glass border border-white/20 hover:border-emerald-400/50 hover:glass-strong"
                  }`}
                >
                  <div className="flex justify-between items-start">
                    <div>
                      <div className="font-medium mb-1">{condition.label}</div>
                      <div className="text-sm opacity-80">{condition.desc}</div>
                    </div>
                    <div
                      className={`w-4 h-4 rounded-full border-2 ${
                        formData.condition === condition.id ? "bg-white border-white" : "border-gray-400"
                      }`}
                    />
                  </div>
                </button>
              ))}
            </div>
          </div>

          {/* Eco-Friendly Toggle */}
          <div className="glass-strong rounded-2xl p-6">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-3">
                <Sparkles className="w-6 h-6 text-emerald-400" />
                <div>
                  <h3 className="text-lg font-semibold text-white">Eco Premium</h3>
                  <p className="text-sm text-gray-300">Mark as environmentally friendly</p>
                </div>
              </div>

              <div className="flex items-center space-x-3">
                <button
                  type="button"
                  onClick={() => setShowEcoInfo(!showEcoInfo)}
                  className="text-gray-400 hover:text-emerald-400 transition-colors duration-200"
                >
                  <Info className="w-5 h-5" />
                </button>

                <button
                  type="button"
                  onClick={() => handleInputChange("ecoFriendly", !formData.ecoFriendly)}
                  className={`relative w-12 h-6 rounded-full transition-all duration-300 ${
                    formData.ecoFriendly ? "eco-gradient neon-glow" : "bg-gray-600"
                  }`}
                >
                  <div
                    className={`absolute top-1 w-4 h-4 bg-white rounded-full transition-transform duration-300 ${
                      formData.ecoFriendly ? "translate-x-7" : "translate-x-1"
                    }`}
                  />
                </button>
              </div>
            </div>

            {showEcoInfo && (
              <div className="mt-4 p-4 glass rounded-lg border border-emerald-400/30">
                <h4 className="font-medium text-emerald-400 mb-2">What qualifies as Eco Premium?</h4>
                <ul className="text-sm text-gray-300 space-y-1">
                  <li>• Handmade or artisanal items</li>
                  <li>• Made from recycled materials</li>
                  <li>• Organic or sustainable materials</li>
                  <li>• Vintage items (reducing waste)</li>
                  <li>• Items that promote sustainability</li>
                </ul>
              </div>
            )}
          </div>

          {/* Submit Button */}
          <div className="text-center">
            <Button
              type="submit"
              className="eco-gradient text-white px-12 py-4 text-lg rounded-full neon-glow hover:scale-105 transition-all duration-300"
            >
              Post Item
            </Button>
          </div>
        </form>
      </div>
    </div>
  )
}
