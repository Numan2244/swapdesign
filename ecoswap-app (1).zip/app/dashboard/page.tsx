"use client"

import { useState } from "react"
import { Edit, Award, MessageCircle, TrendingUp, Calendar, MapPin, Star } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { EditProfileModal } from "@/components/edit-profile-modal"
import { ScrollReveal } from "@/components/scroll-reveal"

interface UserStats {
  itemsPosted: number
  swapsCompleted: number
  co2Saved: number
  communityRank: number
  joinDate: string
  location: string
  rating: number
  totalRatings: number
}

interface Achievement {
  id: number
  title: string
  description: string
  icon: string
  unlocked: boolean
  progress?: number
  maxProgress?: number
}

interface RecentActivity {
  id: number
  type: "swap" | "post" | "message"
  title: string
  description: string
  timestamp: string
  image?: string
}

const mockUserStats: UserStats = {
  itemsPosted: 23,
  swapsCompleted: 18,
  co2Saved: 12.4,
  communityRank: 156,
  joinDate: "March 2024",
  location: "Downtown District",
  rating: 4.8,
  totalRatings: 24,
}

const achievements: Achievement[] = [
  {
    id: 1,
    title: "First Swap",
    description: "Complete your first successful swap",
    icon: "🎉",
    unlocked: true,
  },
  {
    id: 2,
    title: "Eco Warrior",
    description: "Save 10kg of CO₂ through swapping",
    icon: "🌱",
    unlocked: true,
  },
  {
    id: 3,
    title: "Community Helper",
    description: "Help 25 community members",
    icon: "🤝",
    unlocked: true,
    progress: 18,
    maxProgress: 25,
  },
  {
    id: 4,
    title: "Swap Master",
    description: "Complete 50 successful swaps",
    icon: "🏆",
    unlocked: false,
    progress: 18,
    maxProgress: 50,
  },
  {
    id: 5,
    title: "Green Champion",
    description: "Save 25kg of CO₂",
    icon: "🌍",
    unlocked: false,
    progress: 12.4,
    maxProgress: 25,
  },
  {
    id: 6,
    title: "Social Butterfly",
    description: "Chat with 100 different users",
    icon: "💬",
    unlocked: false,
    progress: 67,
    maxProgress: 100,
  },
]

const recentActivity: RecentActivity[] = [
  {
    id: 1,
    type: "swap",
    title: "Swapped Vintage Jacket",
    description: "Successfully swapped with Sarah M.",
    timestamp: "2 hours ago",
    image: "/images/vintage-denim-jacket.jpg",
  },
  {
    id: 2,
    type: "message",
    title: "New Message",
    description: "Alex K. sent you a message about books",
    timestamp: "5 hours ago",
  },
  {
    id: 3,
    type: "post",
    title: "Posted New Item",
    description: "Handmade Ceramic Vase",
    timestamp: "1 day ago",
    image: "/images/ceramic-vase.jpg",
  },
  {
    id: 4,
    type: "swap",
    title: "Swap Completed",
    description: "Programming books with Jordan L.",
    timestamp: "3 days ago",
    image: "/images/programming-books.jpg",
  },
]

export default function DashboardPage() {
  const [activeTab, setActiveTab] = useState<"overview" | "achievements" | "activity" | "history">("overview")
  const [showEditModal, setShowEditModal] = useState(false)
  const [userProfile, setUserProfile] = useState({
    name: "John Doe",
    email: "john@example.com",
    bio: "Passionate about sustainable living and community sharing. Love swapping items and reducing waste!",
    location: "Downtown District",
    avatar: "",
  })

  // Add EcoPoints calculation
  const ecoPoints = mockUserStats.swapsCompleted * 10 + mockUserStats.co2Saved * 5 + mockUserStats.itemsPosted * 3
  const ecoPointsProgress = ((ecoPoints % 100) / 100) * 100 // Progress to next level

  // Mock swap history data
  const swapHistory = [
    {
      id: 1,
      itemName: "Vintage Denim Jacket",
      swappedWith: "Sarah M.",
      date: "2024-01-15",
      image: "/images/vintage-denim-jacket.jpg",
    },
    {
      id: 2,
      itemName: "Programming Books Set",
      swappedWith: "Alex K.",
      date: "2024-01-10",
      image: "/images/programming-books.jpg",
    },
    {
      id: 3,
      itemName: "Wireless Headphones",
      swappedWith: "Jordan L.",
      date: "2024-01-05",
      image: "/images/bluetooth-headphones.webp",
    },
    {
      id: 4,
      itemName: "Ceramic Plant Pot",
      swappedWith: "Maya P.",
      date: "2023-12-28",
      image: "/images/ceramic-vase.jpg",
    },
  ]

  const getProgressPercentage = (current: number, max: number) => {
    return Math.min((current / max) * 100, 100)
  }

  const getActivityIcon = (type: string) => {
    switch (type) {
      case "swap":
        return "🔄"
      case "post":
        return "📝"
      case "message":
        return "💬"
      default:
        return "📋"
    }
  }

  return (
    <div className="min-h-screen pt-20 pb-20 md:pb-8">
      <div className="container mx-auto px-4 max-w-6xl">
        {/* Header */}
        <div className="flex flex-col md:flex-row items-start md:items-center justify-between mb-8">
          <div>
            <h1 className="text-5xl font-bold gradient-text mb-2">Dashboard</h1>
            <p className="text-xl text-gray-300">Welcome back, EcoSwapper!</p>
          </div>
          <Button
            onClick={() => setShowEditModal(true)}
            className="mt-4 md:mt-0 eco-gradient text-white px-6 py-2 rounded-full neon-glow hover:scale-105 transition-all duration-300"
          >
            <Edit className="w-4 h-4 mr-2" />
            Edit Profile
          </Button>
        </div>

        {/* Profile Card */}
        <div className="glass-strong rounded-3xl p-8 mb-8">
          <div className="flex flex-col md:flex-row items-center md:items-start space-y-6 md:space-y-0 md:space-x-8">
            {/* Avatar */}
            <div className="relative">
              <div className="w-32 h-32 rounded-full bg-gradient-to-br from-emerald-400 to-blue-500 p-1">
                <div className="w-full h-full rounded-full bg-gray-800 flex items-center justify-center text-4xl">
                  👤
                </div>
              </div>
              <div className="absolute -bottom-2 -right-2 glass rounded-full p-2 neon-glow">
                <Award className="w-6 h-6 text-emerald-400" />
              </div>
            </div>

            {/* Profile Info */}
            <div className="flex-1 text-center md:text-left">
              <h2 className="text-3xl font-bold text-white mb-2">John Doe</h2>
              <div className="flex flex-col md:flex-row items-center md:items-start space-y-2 md:space-y-0 md:space-x-6 text-gray-300 mb-4">
                <div className="flex items-center">
                  <MapPin className="w-4 h-4 mr-2" />
                  {mockUserStats.location}
                </div>
                <div className="flex items-center">
                  <Calendar className="w-4 h-4 mr-2" />
                  Joined {mockUserStats.joinDate}
                </div>
                <div className="flex items-center">
                  <Star className="w-4 h-4 mr-2 text-yellow-400 fill-current" />
                  {mockUserStats.rating} ({mockUserStats.totalRatings} reviews)
                </div>
              </div>

              <div className="flex flex-wrap justify-center md:justify-start gap-3">
                <Badge className="eco-gradient text-white border-0">Eco Champion</Badge>
                <Badge className="bg-purple-500/20 text-purple-400 border-purple-400/30">Top Swapper</Badge>
                <Badge className="bg-blue-500/20 text-blue-400 border-blue-400/30">Community Helper</Badge>
              </div>
            </div>
          </div>
        </div>

        {/* Stats Grid */}
        <ScrollReveal>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-6 mb-8">
            <ScrollReveal delay={0}>
              <div className="glass-strong rounded-2xl p-6 text-center hover:neon-glow transition-all duration-300">
                <div className="text-4xl mb-3">📦</div>
                <h3 className="text-3xl font-bold gradient-text mb-2">{mockUserStats.itemsPosted}</h3>
                <p className="text-gray-300">Items Posted</p>
              </div>
            </ScrollReveal>

            <ScrollReveal delay={100}>
              <div className="glass-strong rounded-2xl p-6 text-center hover:neon-glow-purple transition-all duration-300">
                <div className="text-4xl mb-3">🔄</div>
                <h3 className="text-3xl font-bold gradient-text mb-2">{mockUserStats.swapsCompleted}</h3>
                <p className="text-gray-300">Swaps Completed</p>
              </div>
            </ScrollReveal>

            <ScrollReveal delay={200}>
              <div className="glass-strong rounded-2xl p-6 text-center hover:neon-glow-blue transition-all duration-300">
                <div className="text-4xl mb-3">🌱</div>
                <h3 className="text-3xl font-bold gradient-text mb-2">{mockUserStats.co2Saved}kg</h3>
                <p className="text-gray-300">CO₂ Saved</p>
              </div>
            </ScrollReveal>

            <ScrollReveal delay={300}>
              <div className="glass-strong rounded-2xl p-6 text-center hover:neon-glow transition-all duration-300">
                <div className="text-4xl mb-3">🏆</div>
                <h3 className="text-3xl font-bold gradient-text mb-2">#{mockUserStats.communityRank}</h3>
                <p className="text-gray-300">Community Rank</p>
              </div>
            </ScrollReveal>

            {/* EcoPoints Card */}
            <ScrollReveal delay={400}>
              <div className="glass-strong rounded-2xl p-6 text-center hover:neon-glow transition-all duration-300">
                <div className="relative w-16 h-16 mx-auto mb-3">
                  <svg className="w-16 h-16 transform -rotate-90" viewBox="0 0 64 64">
                    <circle cx="32" cy="32" r="28" stroke="rgba(16, 185, 129, 0.2)" strokeWidth="4" fill="none" />
                    <circle
                      cx="32"
                      cy="32"
                      r="28"
                      stroke="url(#ecoGradient)"
                      strokeWidth="4"
                      fill="none"
                      strokeDasharray={`${ecoPointsProgress * 1.76} 176`}
                      className="transition-all duration-1000 ease-out"
                    />
                    <defs>
                      <linearGradient id="ecoGradient" x1="0%" y1="0%" x2="100%" y2="0%">
                        <stop offset="0%" stopColor="#10b981" />
                        <stop offset="100%" stopColor="#3b82f6" />
                      </linearGradient>
                    </defs>
                  </svg>
                  <div className="absolute inset-0 flex items-center justify-center text-2xl">⭐</div>
                </div>
                <h3 className="text-3xl font-bold gradient-text mb-2">{ecoPoints}</h3>
                <p className="text-gray-300">EcoPoints</p>
              </div>
            </ScrollReveal>
          </div>
        </ScrollReveal>

        {/* Tabs */}
        <div className="glass-strong rounded-2xl overflow-hidden">
          <div className="flex border-b border-white/10">
            {[
              { id: "overview", label: "Overview", icon: TrendingUp },
              { id: "achievements", label: "Achievements", icon: Award },
              { id: "history", label: "Swap History", icon: MessageCircle },
              { id: "activity", label: "Recent Activity", icon: MessageCircle },
            ].map((tab) => {
              const Icon = tab.icon
              return (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id as any)}
                  className={`flex-1 flex items-center justify-center px-6 py-4 transition-all duration-300 ${
                    activeTab === tab.id
                      ? "eco-gradient text-white neon-glow"
                      : "text-gray-300 hover:text-emerald-400 hover:bg-white/5"
                  }`}
                >
                  <Icon className="w-5 h-5 mr-2" />
                  {tab.label}
                </button>
              )
            })}
          </div>

          <div className="p-8">
            {/* Overview Tab */}
            {activeTab === "overview" && (
              <div className="space-y-8">
                <div>
                  <h3 className="text-2xl font-semibold text-white mb-6">Progress Overview</h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    {/* Swap Progress */}
                    <div className="glass rounded-xl p-6">
                      <h4 className="text-lg font-medium text-white mb-4">Swap Progress</h4>
                      <div className="space-y-4">
                        <div>
                          <div className="flex justify-between text-sm mb-2">
                            <span className="text-gray-300">Monthly Goal</span>
                            <span className="text-emerald-400">{mockUserStats.swapsCompleted}/20</span>
                          </div>
                          <div className="w-full bg-gray-700 rounded-full h-2">
                            <div
                              className="eco-gradient h-2 rounded-full transition-all duration-500"
                              style={{ width: `${getProgressPercentage(mockUserStats.swapsCompleted, 20)}%` }}
                            />
                          </div>
                        </div>
                      </div>
                    </div>

                    {/* Environmental Impact */}
                    <div className="glass rounded-xl p-6">
                      <h4 className="text-lg font-medium text-white mb-4">Environmental Impact</h4>
                      <div className="space-y-4">
                        <div>
                          <div className="flex justify-between text-sm mb-2">
                            <span className="text-gray-300">CO₂ Saved This Month</span>
                            <span className="text-emerald-400">{mockUserStats.co2Saved}/15kg</span>
                          </div>
                          <div className="w-full bg-gray-700 rounded-full h-2">
                            <div
                              className="bg-gradient-to-r from-green-500 to-emerald-500 h-2 rounded-full transition-all duration-500"
                              style={{ width: `${getProgressPercentage(mockUserStats.co2Saved, 15)}%` }}
                            />
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* Achievements Tab */}
            {activeTab === "achievements" && (
              <div>
                <h3 className="text-2xl font-semibold text-white mb-6">Your Achievements</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {achievements.map((achievement) => (
                    <div
                      key={achievement.id}
                      className={`glass rounded-xl p-6 transition-all duration-300 ${
                        achievement.unlocked ? "neon-glow hover:scale-105" : "opacity-60 hover:opacity-80"
                      }`}
                    >
                      <div className="text-center">
                        <div className={`text-5xl mb-4 ${achievement.unlocked ? "animate-float" : "grayscale"}`}>
                          {achievement.icon}
                        </div>
                        <h4
                          className={`text-lg font-semibold mb-2 ${
                            achievement.unlocked ? "text-emerald-400" : "text-gray-400"
                          }`}
                        >
                          {achievement.title}
                        </h4>
                        <p className="text-sm text-gray-300 mb-4">{achievement.description}</p>

                        {achievement.progress !== undefined && achievement.maxProgress && (
                          <div className="space-y-2">
                            <div className="flex justify-between text-xs">
                              <span className="text-gray-400">Progress</span>
                              <span className="text-emerald-400">
                                {achievement.progress}/{achievement.maxProgress}
                              </span>
                            </div>
                            <div className="w-full bg-gray-700 rounded-full h-2">
                              <div
                                className="eco-gradient h-2 rounded-full transition-all duration-500"
                                style={{
                                  width: `${getProgressPercentage(achievement.progress, achievement.maxProgress)}%`,
                                }}
                              />
                            </div>
                          </div>
                        )}

                        {achievement.unlocked && (
                          <Badge className="mt-3 eco-gradient text-white border-0">Unlocked!</Badge>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Activity Tab */}
            {activeTab === "activity" && (
              <div>
                <h3 className="text-2xl font-semibold text-white mb-6">Recent Activity</h3>
                <div className="space-y-4">
                  {recentActivity.map((activity) => (
                    <div
                      key={activity.id}
                      className="glass rounded-xl p-6 hover:glass-strong transition-all duration-300"
                    >
                      <div className="flex items-center space-x-4">
                        {activity.image ? (
                          <img
                            src={activity.image || "/placeholder.svg"}
                            alt=""
                            className="w-12 h-12 rounded-lg object-cover hover:scale-105 transition-transform duration-300"
                            style={{
                              boxShadow: "0 0 8px rgba(16, 185, 129, 0.3)",
                              border: "1px solid rgba(255, 255, 255, 0.2)",
                            }}
                          />
                        ) : (
                          <div className="w-12 h-12 rounded-lg bg-gradient-to-br from-emerald-400 to-blue-500 flex items-center justify-center text-xl">
                            {getActivityIcon(activity.type)}
                          </div>
                        )}

                        <div className="flex-1">
                          <h4 className="text-lg font-medium text-white mb-1">{activity.title}</h4>
                          <p className="text-gray-300 text-sm mb-2">{activity.description}</p>
                          <span className="text-xs text-gray-400">{activity.timestamp}</span>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Swap History Tab */}
            {activeTab === "history" && (
              <div>
                <h3 className="text-2xl font-semibold text-white mb-6">Your Swap History</h3>
                <div className="space-y-4">
                  {swapHistory.map((swap) => (
                    <div key={swap.id} className="glass rounded-xl p-6 hover:glass-strong transition-all duration-300">
                      <div className="flex items-center space-x-4">
                        <img
                          src={swap.image || "/placeholder.svg"}
                          alt={swap.itemName}
                          className="w-12 h-12 rounded-lg object-cover hover:scale-105 transition-transform duration-300"
                          style={{
                            boxShadow: "0 0 8px rgba(16, 185, 129, 0.3)",
                            border: "1px solid rgba(255, 255, 255, 0.2)",
                          }}
                        />

                        <div className="flex-1">
                          <h4 className="text-lg font-medium text-white mb-1">{swap.itemName}</h4>
                          <p className="text-gray-300 text-sm mb-2">Swapped with {swap.swappedWith}</p>
                          <span className="text-xs text-gray-400">{new Date(swap.date).toLocaleDateString()}</span>
                        </div>

                        <div className="text-emerald-400">
                          <div className="text-2xl">✅</div>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>
        {/* Edit Profile Modal */}
        <EditProfileModal
          isOpen={showEditModal}
          onClose={() => setShowEditModal(false)}
          userProfile={userProfile}
          onSave={(newProfile) => {
            setUserProfile(newProfile)
            // Here you would typically save to backend
            console.log("Profile updated:", newProfile)
          }}
        />
      </div>
    </div>
  )
}
