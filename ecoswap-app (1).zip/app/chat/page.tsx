"use client"

import type React from "react"

import { useState, useEffect, useRef } from "react"
import { Send, Phone, Video, MoreVertical, Smile, Paperclip } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"

interface Message {
  id: number
  sender: string
  text: string
  timestamp: string
  isOwn: boolean
}

interface Chat {
  id: number
  user: {
    name: string
    avatar: string
    online: boolean
    lastSeen?: string
  }
  item: {
    title: string
    image: string
  }
  messages: Message[]
}

const mockChats: Chat[] = [
  {
    id: 1,
    user: {
      name: "Sarah M.",
      avatar: "/placeholder.svg?height=40&width=40",
      online: true,
    },
    item: {
      title: "Vintage Denim Jacket",
      image: "/images/vintage-denim-jacket.jpg",
    },
    messages: [
      {
        id: 1,
        sender: "Sarah M.",
        text: "Hi! I'm interested in your vintage denim jacket. Is it still available?",
        timestamp: "2:30 PM",
        isOwn: false,
      },
      {
        id: 2,
        sender: "You",
        text: "Yes, it's still available! It's in great condition, barely worn.",
        timestamp: "2:32 PM",
        isOwn: true,
      },
      {
        id: 3,
        sender: "Sarah M.",
        text: "Perfect! What would you like to swap it for?",
        timestamp: "2:33 PM",
        isOwn: false,
      },
      {
        id: 4,
        sender: "You",
        text: "I'm looking for books, especially programming or design related. What do you have?",
        timestamp: "2:35 PM",
        isOwn: true,
      },
    ],
  },
  {
    id: 2,
    user: {
      name: "Alex K.",
      avatar: "/placeholder.svg?height=40&width=40",
      online: false,
      lastSeen: "1 hour ago",
    },
    item: {
      title: "Programming Books Collection",
      image: "/images/programming-books.jpg",
    },
    messages: [
      {
        id: 1,
        sender: "Alex K.",
        text: "Hey! Saw your post about the ceramic vase. Would you be interested in trading for some programming books?",
        timestamp: "1:15 PM",
        isOwn: false,
      },
      {
        id: 2,
        sender: "You",
        text: "That sounds great! Which books do you have?",
        timestamp: "1:20 PM",
        isOwn: true,
      },
    ],
  },
]

export default function ChatPage() {
  const [selectedChat, setSelectedChat] = useState<Chat>(mockChats[0])
  const [newMessage, setNewMessage] = useState("")
  const [isTyping, setIsTyping] = useState(false)
  const messagesEndRef = useRef<HTMLDivElement>(null)

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" })
  }

  useEffect(() => {
    scrollToBottom()
  }, [selectedChat.messages])

  const handleSendMessage = (e: React.FormEvent) => {
    e.preventDefault()
    if (!newMessage.trim()) return

    const message: Message = {
      id: selectedChat.messages.length + 1,
      sender: "You",
      text: newMessage,
      timestamp: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
      isOwn: true,
    }

    setSelectedChat((prev) => ({
      ...prev,
      messages: [...prev.messages, message],
    }))

    setNewMessage("")

    // Simulate typing indicator and response
    setIsTyping(true)
    setTimeout(() => {
      setIsTyping(false)
      const response: Message = {
        id: selectedChat.messages.length + 2,
        sender: selectedChat.user.name,
        text: "Thanks for the message! Let me check and get back to you.",
        timestamp: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
        isOwn: false,
      }
      setSelectedChat((prev) => ({
        ...prev,
        messages: [...prev.messages, response],
      }))
    }, 2000)
  }

  return (
    <div className="min-h-screen pt-20 pb-20 md:pb-8">
      <div className="container mx-auto px-4 max-w-6xl">
        {/* Header */}
        <div className="text-center mb-8">
          <h1 className="text-5xl font-bold gradient-text mb-4">Messages</h1>
          <p className="text-xl text-gray-300">Connect with your community</p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 h-[600px]">
          {/* Chat List */}
          <div className="glass-strong rounded-2xl overflow-hidden">
            <div className="p-4 border-b border-white/10">
              <h2 className="text-lg font-semibold text-white">Conversations</h2>
            </div>

            <div className="overflow-y-auto h-full">
              {mockChats.map((chat) => (
                <button
                  key={chat.id}
                  onClick={() => setSelectedChat(chat)}
                  className={`w-full p-4 text-left hover:glass transition-all duration-300 border-b border-white/5 ${
                    selectedChat.id === chat.id ? "glass neon-glow" : ""
                  }`}
                >
                  <div className="flex items-center space-x-3">
                    <div className="relative">
                      <img
                        src={chat.user.avatar || "/placeholder.svg"}
                        alt={chat.user.name}
                        className="w-12 h-12 rounded-full"
                      />
                      {chat.user.online && (
                        <div className="absolute -bottom-1 -right-1 w-4 h-4 bg-emerald-400 rounded-full border-2 border-gray-900 animate-glow-pulse" />
                      )}
                    </div>

                    <div className="flex-1 min-w-0">
                      <div className="flex items-center justify-between mb-1">
                        <h3 className="font-medium text-white truncate">{chat.user.name}</h3>
                        <span className="text-xs text-gray-400">
                          {chat.messages[chat.messages.length - 1]?.timestamp}
                        </span>
                      </div>

                      <p className="text-sm text-gray-300 truncate">{chat.messages[chat.messages.length - 1]?.text}</p>

                      <div className="flex items-center mt-2">
                        <img
                          src={chat.item.image || "/placeholder.svg"}
                          alt={chat.item.title}
                          className="w-6 h-6 rounded object-cover mr-2"
                        />
                        <span className="text-xs text-gray-400 truncate">{chat.item.title}</span>
                      </div>
                    </div>
                  </div>
                </button>
              ))}
            </div>
          </div>

          {/* Chat Window */}
          <div className="lg:col-span-2 glass-strong rounded-2xl overflow-hidden flex flex-col">
            {/* Chat Header */}
            <div className="p-4 border-b border-white/10 flex items-center justify-between">
              <div className="flex items-center space-x-3">
                <div className="relative">
                  <img
                    src={selectedChat.user.avatar || "/placeholder.svg"}
                    alt={selectedChat.user.name}
                    className="w-10 h-10 rounded-full"
                  />
                  {selectedChat.user.online && (
                    <div className="absolute -bottom-1 -right-1 w-3 h-3 bg-emerald-400 rounded-full border-2 border-gray-900" />
                  )}
                </div>

                <div>
                  <h3 className="font-medium text-white">{selectedChat.user.name}</h3>
                  <p className="text-sm text-gray-400">
                    {selectedChat.user.online ? (
                      <span className="flex items-center">
                        <span className="w-2 h-2 bg-emerald-400 rounded-full mr-2 animate-glow-pulse" />
                        Online
                      </span>
                    ) : (
                      `Last seen ${selectedChat.user.lastSeen}`
                    )}
                  </p>
                </div>
              </div>

              <div className="flex items-center space-x-2">
                <Button variant="ghost" size="sm" className="text-gray-400 hover:text-emerald-400">
                  <Phone className="w-4 h-4" />
                </Button>
                <Button variant="ghost" size="sm" className="text-gray-400 hover:text-emerald-400">
                  <Video className="w-4 h-4" />
                </Button>
                <Button variant="ghost" size="sm" className="text-gray-400 hover:text-emerald-400">
                  <MoreVertical className="w-4 h-4" />
                </Button>
              </div>
            </div>

            {/* Item Context */}
            <div className="p-3 bg-gradient-to-r from-emerald-500/10 to-blue-500/10 border-b border-white/10">
              <div className="flex items-center space-x-3">
                <div className="relative">
                  <img
                    src={selectedChat.item.image || "/placeholder.svg"}
                    alt={selectedChat.item.title}
                    className="w-12 h-12 rounded-lg object-cover hover:scale-105 transition-transform duration-300"
                    style={{
                      boxShadow: "0 0 10px rgba(16, 185, 129, 0.3)",
                      border: "1px solid rgba(255, 255, 255, 0.2)",
                    }}
                  />
                  <div className="absolute inset-0 glass rounded-lg opacity-0 hover:opacity-20 transition-opacity duration-300" />
                </div>
                <div>
                  <p className="text-sm font-medium text-white">Discussing:</p>
                  <p className="text-sm text-emerald-400">{selectedChat.item.title}</p>
                </div>
              </div>
            </div>

            {/* Messages */}
            <div className="flex-1 overflow-y-auto p-4 space-y-4">
              {selectedChat.messages.map((message) => (
                <div key={message.id} className={`flex ${message.isOwn ? "justify-end" : "justify-start"}`}>
                  <div
                    className={`max-w-xs lg:max-w-md px-4 py-2 rounded-2xl ${
                      message.isOwn ? "eco-gradient text-white neon-glow" : "glass border border-white/20 text-white"
                    }`}
                  >
                    <p className="text-sm">{message.text}</p>
                    <p className={`text-xs mt-1 ${message.isOwn ? "text-white/80" : "text-gray-400"}`}>
                      {message.timestamp}
                    </p>
                  </div>
                </div>
              ))}

              {/* Typing Indicator */}
              {isTyping && (
                <div className="flex justify-start">
                  <div className="glass border border-white/20 px-4 py-2 rounded-2xl">
                    <div className="flex space-x-1">
                      <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" />
                      <div
                        className="w-2 h-2 bg-gray-400 rounded-full animate-bounce"
                        style={{ animationDelay: "0.1s" }}
                      />
                      <div
                        className="w-2 h-2 bg-gray-400 rounded-full animate-bounce"
                        style={{ animationDelay: "0.2s" }}
                      />
                    </div>
                  </div>
                </div>
              )}

              <div ref={messagesEndRef} />
            </div>

            {/* Message Input */}
            <form onSubmit={handleSendMessage} className="p-4 border-t border-white/10">
              <div className="flex items-center space-x-3">
                <Button type="button" variant="ghost" size="sm" className="text-gray-400 hover:text-emerald-400">
                  <Paperclip className="w-4 h-4" />
                </Button>

                <div className="flex-1 relative">
                  <Input
                    value={newMessage}
                    onChange={(e) => setNewMessage(e.target.value)}
                    placeholder="Type a message..."
                    className="border-white/20 text-emerald-400 placeholder-gray-400 backdrop-blur-md focus:border-emerald-400 focus:neon-glow transition-all duration-300 pr-12"
                    style={{
                      backgroundColor: "rgba(20, 20, 20, 0.6)",
                      backdropFilter: "blur(12px)",
                      border: "1px solid rgba(255, 255, 255, 0.2)",
                      borderRadius: "0.75rem",
                    }}
                  />
                  <Button
                    type="button"
                    variant="ghost"
                    size="sm"
                    className="absolute right-2 top-1/2 transform -translate-y-1/2 text-gray-400 hover:text-emerald-400"
                  >
                    <Smile className="w-4 h-4" />
                  </Button>
                </div>

                <Button
                  type="submit"
                  className="eco-gradient text-white p-2 rounded-full neon-glow hover:scale-105 hover:neon-glow transition-all duration-300"
                  disabled={!newMessage.trim()}
                >
                  <Send className="w-4 h-4" />
                </Button>
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>
  )
}
