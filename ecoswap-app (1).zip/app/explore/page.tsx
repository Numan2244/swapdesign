"use client"

import { useState, useEffect } from "react"
import { Search, Filter, MapPin, Star, Sparkles } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { ScrollReveal } from "@/components/scroll-reveal"
import { SwapRequestModal } from "@/components/swap-request-modal"
import { SuccessNotification } from "@/components/success-notification"

interface SwapItem {
  id: number
  title: string
  description: string
  category: string
  condition: string
  location: string
  image: string
  eco: boolean
  user: string
  rating: number
}

const mockItems: SwapItem[] = [
  {
    id: 1,
    title: "Vintage Denim Jacket",
    description: "Classic 90s denim jacket in excellent condition. Perfect for sustainable fashion lovers.",
    category: "clothing",
    condition: "Used",
    location: "Downtown",
    image: "/images/vintage-denim-jacket.jpg",
    eco: true,
    user: "Sarah M.",
    rating: 4.8,
  },
  {
    id: 2,
    title: "Programming Books Collection",
    description: "Set of 5 programming books including React, Node.js, and Python guides.",
    category: "books",
    condition: "Good",
    location: "Tech District",
    image: "/images/programming-books.jpg",
    eco: false,
    user: "Alex K.",
    rating: 4.9,
  },
  {
    id: 3,
    title: "Handmade Ceramic Vase",
    description: "Beautiful handcrafted ceramic vase, perfect for home decoration.",
    category: "home",
    condition: "New",
    location: "Arts Quarter",
    image: "/images/ceramic-vase.jpg",
    eco: true,
    user: "Maya P.",
    rating: 5.0,
  },
  {
    id: 4,
    title: "Wireless Bluetooth Headphones",
    description: "High-quality wireless headphones with noise cancellation.",
    category: "electronics",
    condition: "Like New",
    location: "University Area",
    image: "/images/bluetooth-headphones.webp",
    eco: false,
    user: "Jordan L.",
    rating: 4.7,
  },
  {
    id: 5,
    title: "Organic Cotton T-Shirts",
    description: "Set of 3 organic cotton t-shirts, sustainably made.",
    category: "clothing",
    condition: "New",
    location: "Green District",
    image: "/images/organic-cotton-tshirt.jpg",
    eco: true,
    user: "Emma R.",
    rating: 4.9,
  },
  {
    id: 6,
    title: "Vintage Camera Collection",
    description: "Collection of vintage film cameras for photography enthusiasts.",
    category: "electronics",
    condition: "Vintage",
    location: "Historic Center",
    image: "/images/vintage-cameras.jpg",
    eco: true,
    user: "David C.",
    rating: 4.6,
  },
]

const categories = ["all", "clothing", "books", "electronics", "home", "sports", "toys"]
const conditions = ["all", "New", "Like New", "Good", "Used", "Vintage"]

export default function ExplorePage() {
  const [items, setItems] = useState<SwapItem[]>(mockItems)
  const [filteredItems, setFilteredItems] = useState<SwapItem[]>(mockItems)
  const [searchTerm, setSearchTerm] = useState("")
  const [selectedCategory, setSelectedCategory] = useState("all")
  const [selectedCondition, setSelectedCondition] = useState("all")
  const [showFilters, setShowFilters] = useState(false)
  const [selectedItem, setSelectedItem] = useState<SwapItem | null>(null)
  const [showRequestModal, setShowRequestModal] = useState(false)
  const [showSuccessNotification, setShowSuccessNotification] = useState(false)
  const [successMessage, setSuccessMessage] = useState("")
  const [swapRequests, setSwapRequests] = useState<
    Array<{ id: number; itemId: number; message: string; timestamp: string }>
  >([])

  useEffect(() => {
    let filtered = items

    if (searchTerm) {
      filtered = filtered.filter(
        (item) =>
          item.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
          item.description.toLowerCase().includes(searchTerm.toLowerCase()),
      )
    }

    if (selectedCategory !== "all") {
      filtered = filtered.filter((item) => item.category === selectedCategory)
    }

    if (selectedCondition !== "all") {
      filtered = filtered.filter((item) => item.condition === selectedCondition)
    }

    setFilteredItems(filtered)
  }, [searchTerm, selectedCategory, selectedCondition, items])

  const getCategoryColor = (category: string) => {
    const colors = {
      clothing: "bg-pink-500/20 text-pink-400 border-pink-400/30",
      books: "bg-blue-500/20 text-blue-400 border-blue-400/30",
      electronics: "bg-purple-500/20 text-purple-400 border-purple-400/30",
      home: "bg-green-500/20 text-green-400 border-green-400/30",
      sports: "bg-orange-500/20 text-orange-400 border-orange-400/30",
      toys: "bg-yellow-500/20 text-yellow-400 border-yellow-400/30",
    }
    return colors[category as keyof typeof colors] || "bg-gray-500/20 text-gray-400 border-gray-400/30"
  }

  const handleSwapRequest = (item: SwapItem) => {
    setSelectedItem(item)
    setShowRequestModal(true)
  }

  const handleConfirmRequest = (message: string) => {
    if (!selectedItem) return

    // Save request to local state
    const newRequest = {
      id: Date.now(),
      itemId: selectedItem.id,
      message,
      timestamp: new Date().toISOString(),
    }

    setSwapRequests((prev) => [...prev, newRequest])

    // Show success notification
    setSuccessMessage("Swap Request Sent!")
    setShowSuccessNotification(true)

    // Optional: Log to console for debugging
    console.log("Swap request sent:", newRequest)
  }

  return (
    <div className="min-h-screen pt-20 pb-20 md:pb-8">
      <div className="container mx-auto px-4">
        {/* Header */}
        <div className="text-center mb-12">
          <h1 className="text-5xl font-bold gradient-text mb-4">Explore Swaps</h1>
          <p className="text-xl text-gray-300">Discover amazing items from your community</p>
        </div>

        {/* Search and Filters */}
        <div className="glass-strong rounded-2xl p-6 mb-8">
          <div className="flex flex-col lg:flex-row gap-4">
            {/* Search */}
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
              <Input
                placeholder="Search items..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10 glass border-white/20 text-white placeholder-gray-400"
              />
            </div>

            {/* Filter Toggle */}
            <Button
              onClick={() => setShowFilters(!showFilters)}
              variant="outline"
              className="border-emerald-400 text-emerald-400 hover:bg-emerald-400 hover:text-gray-900"
            >
              <Filter className="w-4 h-4 mr-2" />
              Filters
            </Button>
          </div>

          {/* Filters */}
          {showFilters && (
            <div className="mt-6 pt-6 border-t border-white/20">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {/* Category Filter */}
                <div>
                  <label className="block text-sm font-medium text-gray-300 mb-3">Category</label>
                  <div className="flex flex-wrap gap-2">
                    {categories.map((category) => (
                      <button
                        key={category}
                        onClick={() => setSelectedCategory(category)}
                        className={`px-3 py-1 rounded-full text-sm transition-all duration-300 ${
                          selectedCategory === category
                            ? "eco-gradient text-white neon-glow"
                            : "glass border border-white/20 text-gray-300 hover:border-emerald-400/50"
                        }`}
                      >
                        {category.charAt(0).toUpperCase() + category.slice(1)}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Condition Filter */}
                <div>
                  <label className="block text-sm font-medium text-gray-300 mb-3">Condition</label>
                  <div className="flex flex-wrap gap-2">
                    {conditions.map((condition) => (
                      <button
                        key={condition}
                        onClick={() => setSelectedCondition(condition)}
                        className={`px-3 py-1 rounded-full text-sm transition-all duration-300 ${
                          selectedCondition === condition
                            ? "eco-gradient text-white neon-glow"
                            : "glass border border-white/20 text-gray-300 hover:border-emerald-400/50"
                        }`}
                      >
                        {condition.charAt(0).toUpperCase() + condition.slice(1)}
                      </button>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Results Count */}
        <div className="mb-6">
          <p className="text-gray-300">
            Showing {filteredItems.length} of {items.length} items
          </p>
        </div>

        {/* Items Grid */}
        <ScrollReveal>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {filteredItems.map((item, index) => (
              <ScrollReveal key={item.id} delay={index * 100}>
                <div
                  className="group glass rounded-2xl overflow-hidden hover:glass-strong hover:scale-105 hover:neon-glow transition-all duration-500 cursor-pointer"
                  style={{
                    transform: "perspective(1000px) rotateX(0deg) rotateY(0deg)",
                  }}
                  onMouseEnter={(e) => {
                    const rect = e.currentTarget.getBoundingClientRect()
                    const x = e.clientX - rect.left
                    const y = e.clientY - rect.top
                    const centerX = rect.width / 2
                    const centerY = rect.height / 2
                    const rotateX = (y - centerY) / 10
                    const rotateY = (centerX - x) / 10

                    e.currentTarget.style.transform = `perspective(1000px) rotateX(${rotateX}deg) rotateY(${rotateY}deg) scale(1.05)`
                  }}
                  onMouseLeave={(e) => {
                    e.currentTarget.style.transform = "perspective(1000px) rotateX(0deg) rotateY(0deg) scale(1)"
                  }}
                >
                  {/* Image */}
                  <div className="relative h-48 overflow-hidden rounded-t-2xl">
                    <div className="absolute inset-0 glass-strong opacity-0 hover:opacity-20 transition-opacity duration-300 z-10" />
                    <img
                      src={item.image || "/placeholder.svg"}
                      alt={item.title}
                      className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500 filter hover:brightness-110"
                      style={{
                        boxShadow: "inset 0 0 20px rgba(16, 185, 129, 0.1)",
                        borderRadius: "16px 16px 0 0",
                      }}
                    />
                    {item.eco && (
                      <Badge className="absolute top-3 right-3 eco-gradient text-white border-0 neon-glow">
                        <Sparkles className="w-3 h-3 mr-1" />
                        Eco Premium
                      </Badge>
                    )}
                    <div className="absolute top-3 left-3">
                      <Badge className={`border ${getCategoryColor(item.category)}`}>{item.category}</Badge>
                    </div>
                  </div>

                  {/* Content */}
                  <div className="p-6">
                    <div className="flex items-start justify-between mb-3">
                      <h3 className="text-xl font-semibold text-white group-hover:text-emerald-400 transition-colors duration-300">
                        {item.title}
                      </h3>
                      <div className="flex items-center text-yellow-400">
                        <Star className="w-4 h-4 fill-current" />
                        <span className="text-sm ml-1">{item.rating}</span>
                      </div>
                    </div>

                    <p className="text-gray-300 text-sm mb-4 line-clamp-2">{item.description}</p>

                    <div className="flex items-center justify-between mb-4">
                      <div className="flex items-center text-gray-400 text-sm">
                        <MapPin className="w-4 h-4 mr-1" />
                        {item.location}
                      </div>
                      <Badge variant="outline" className="border-gray-400 text-gray-400">
                        {item.condition}
                      </Badge>
                    </div>

                    <div className="flex items-center justify-between">
                      <span className="text-sm text-gray-400">by {item.user}</span>
                      <Button
                        onClick={() => handleSwapRequest(item)}
                        className="eco-gradient text-white px-6 py-2 rounded-full neon-glow hover:scale-105 transition-all duration-300"
                      >
                        Request Swap
                      </Button>
                    </div>
                  </div>
                </div>
              </ScrollReveal>
            ))}
          </div>
        </ScrollReveal>

        {/* No Results */}
        {filteredItems.length === 0 && (
          <div className="text-center py-20">
            <div className="glass-strong rounded-2xl p-12 max-w-md mx-auto">
              <Search className="w-16 h-16 text-gray-400 mx-auto mb-4" />
              <h3 className="text-2xl font-semibold text-white mb-2">No items found</h3>
              <p className="text-gray-300 mb-6">Try adjusting your search or filters</p>
              <Button
                onClick={() => {
                  setSearchTerm("")
                  setSelectedCategory("all")
                  setSelectedCondition("all")
                }}
                className="eco-gradient text-white px-6 py-2 rounded-full"
              >
                Clear Filters
              </Button>
            </div>
          </div>
        )}
        {/* Swap Request Modal */}
        <SwapRequestModal
          isOpen={showRequestModal}
          onClose={() => setShowRequestModal(false)}
          item={selectedItem}
          onConfirm={handleConfirmRequest}
        />

        {/* Success Notification */}
        <SuccessNotification
          isVisible={showSuccessNotification}
          message={successMessage}
          onHide={() => setShowSuccessNotification(false)}
        />
      </div>
    </div>
  )
}
