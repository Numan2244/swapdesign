"use client"

import { useEffect } from "react"
import { CheckCircle } from "lucide-react"

interface SuccessNotificationProps {
  isVisible: boolean
  message: string
  onHide: () => void
}

export function SuccessNotification({ isVisible, message, onHide }: SuccessNotificationProps) {
  useEffect(() => {
    if (isVisible) {
      const timer = setTimeout(() => {
        onHide()
      }, 3000)
      return () => clearTimeout(timer)
    }
  }, [isVisible, onHide])

  if (!isVisible) return null

  return (
    <div className="fixed top-24 right-4 z-50 animate-in slide-in-from-right duration-300">
      <div className="glass-strong rounded-2xl p-4 neon-glow max-w-sm">
        <div className="flex items-center space-x-3">
          <div className="flex-shrink-0">
            <CheckCircle className="w-6 h-6 text-emerald-400 animate-bounce" />
          </div>
          <div>
            <p className="text-white font-medium">{message}</p>
            <p className="text-sm text-gray-300">We'll notify you when they respond!</p>
          </div>
        </div>
      </div>
    </div>
  )
}
