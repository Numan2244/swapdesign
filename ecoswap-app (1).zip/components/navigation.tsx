"use client"

import Link from "next/link"
import { usePathname } from "next/navigation"
import { Home, Search, Plus, MessageCircle, Lightbulb, User } from "lucide-react"
import { cn } from "@/lib/utils"
import { useState } from "react"

const navItems = [
  { href: "/", label: "Home", icon: Home },
  { href: "/explore", label: "Explore", icon: Search },
  { href: "/post", label: "Post Item", icon: Plus },
  { href: "/chat", label: "Chat", icon: MessageCircle },
  { href: "/tips", label: "Eco Tips", icon: Lightbulb },
  { href: "/dashboard", label: "Dashboard", icon: User },
]

export function Navigation() {
  const pathname = usePathname()
  const [hasNewMessages, setHasNewMessages] = useState(true) // Simulate new messages

  return (
    <nav className="fixed top-0 left-0 right-0 z-50 glass border-b border-white/10">
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between h-16">
          <Link href="/" className="text-2xl font-bold gradient-text">
            EcoSwap
          </Link>

          <div className="hidden md:flex items-center space-x-8">
            {navItems.map((item) => {
              const Icon = item.icon
              const isActive = pathname === item.href

              return (
                <Link
                  key={item.href}
                  href={item.href}
                  className={cn(
                    "flex items-center space-x-2 px-3 py-2 rounded-lg transition-all duration-300 hover:scale-105 relative",
                    isActive ? "glass-strong neon-glow text-emerald-400" : "hover:glass hover:text-emerald-400",
                  )}
                >
                  <Icon size={18} />
                  <span>{item.label}</span>
                  {item.href === "/chat" && hasNewMessages && (
                    <div className="absolute -top-1 -right-1 w-3 h-3 bg-red-500 rounded-full animate-glow-pulse border border-white/20" />
                  )}
                </Link>
              )
            })}
          </div>

          {/* Mobile Navigation */}
          <div className="md:hidden">
            <button className="glass p-2 rounded-lg">
              <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" />
              </svg>
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Bottom Navigation */}
      <div className="md:hidden fixed bottom-0 left-0 right-0 glass border-t border-white/10">
        <div className="flex justify-around py-2">
          {navItems.slice(0, 5).map((item) => {
            const Icon = item.icon
            const isActive = pathname === item.href

            return (
              <Link
                key={item.href}
                href={item.href}
                className={cn(
                  "flex flex-col items-center p-2 rounded-lg transition-all duration-300",
                  isActive ? "text-emerald-400 neon-glow" : "text-gray-400 hover:text-emerald-400",
                )}
              >
                <Icon size={20} />
                <span className="text-xs mt-1">{item.label}</span>
                {item.href === "/chat" && hasNewMessages && (
                  <div className="absolute -top-1 -right-1 w-3 h-3 bg-red-500 rounded-full animate-glow-pulse border border-white/20" />
                )}
              </Link>
            )
          })}
        </div>
      </div>
    </nav>
  )
}
