"use client"

import { useEffect, useState } from "react"

export function CursorEffect() {
  const [mousePosition, setMousePosition] = useState({ x: 0, y: 0 })
  const [isVisible, setIsVisible] = useState(false)

  useEffect(() => {
    let animationFrameId: number

    const updateMousePosition = (e: MouseEvent) => {
      animationFrameId = requestAnimationFrame(() => {
        setMousePosition({ x: e.clientX, y: e.clientY })
        setIsVisible(true)
      })
    }

    const handleMouseLeave = () => {
      setIsVisible(false)
    }

    document.addEventListener("mousemove", updateMousePosition)
    document.addEventListener("mouseleave", handleMouseLeave)

    return () => {
      document.removeEventListener("mousemove", updateMousePosition)
      document.removeEventListener("mouseleave", handleMouseLeave)
      if (animationFrameId) {
        cancelAnimationFrame(animationFrameId)
      }
    }
  }, [])

  return (
    <>
      {/* Main cursor glow */}
      <div
        className={`fixed pointer-events-none z-50 transition-opacity duration-300 ${
          isVisible ? "opacity-100" : "opacity-0"
        }`}
        style={{
          left: mousePosition.x - 25,
          top: mousePosition.y - 25,
          width: "50px",
          height: "50px",
          background:
            "radial-gradient(circle, rgba(0, 255, 150, 0.4) 0%, rgba(16, 185, 129, 0.25) 40%, rgba(0, 255, 150, 0.1) 70%, transparent 85%)",
          borderRadius: "50%",
          filter: "blur(12px)",
          transform: "translate3d(0, 0, 0)",
          boxShadow: "0 0 30px rgba(0, 255, 150, 0.3), 0 0 60px rgba(16, 185, 129, 0.2)",
        }}
      />

      {/* Secondary delayed glow */}
      <div
        className={`fixed pointer-events-none z-40 transition-all duration-500 ease-out ${
          isVisible ? "opacity-60" : "opacity-0"
        }`}
        style={{
          left: mousePosition.x - 35,
          top: mousePosition.y - 35,
          width: "70px",
          height: "70px",
          background:
            "radial-gradient(circle, rgba(59, 130, 246, 0.3) 0%, rgba(16, 185, 129, 0.15) 50%, rgba(0, 255, 150, 0.08) 70%, transparent 85%)",
          borderRadius: "50%",
          filter: "blur(16px)",
          transform: "translate3d(0, 0, 0)",
          boxShadow: "0 0 40px rgba(59, 130, 246, 0.2), 0 0 80px rgba(0, 255, 150, 0.15)",
        }}
      />
    </>
  )
}
