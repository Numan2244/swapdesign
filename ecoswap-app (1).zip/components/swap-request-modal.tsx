"use client"

import type React from "react"

import { useState } from "react"
import { X, Send } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Textarea } from "@/components/ui/textarea"

interface SwapItem {
  id: number
  title: string
  image: string
  user: string
}

interface SwapRequestModalProps {
  isOpen: boolean
  onClose: () => void
  item: SwapItem | null
  onConfirm: (message: string) => void
}

export function SwapRequestModal({ isOpen, onClose, item, onConfirm }: SwapRequestModalProps) {
  const [message, setMessage] = useState("")
  const [isSubmitting, setIsSubmitting] = useState(false)

  if (!isOpen || !item) return null

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!message.trim()) return

    setIsSubmitting(true)

    // Simulate API call delay
    await new Promise((resolve) => setTimeout(resolve, 1000))

    onConfirm(message)
    setMessage("")
    setIsSubmitting(false)
    onClose()
  }

  const handleClose = () => {
    setMessage("")
    onClose()
  }

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      {/* Backdrop */}
      <div
        className="absolute inset-0 bg-black/60 backdrop-blur-sm animate-in fade-in duration-300"
        onClick={handleClose}
      />

      {/* Modal */}
      <div className="relative glass-strong rounded-3xl p-8 max-w-md w-full animate-in zoom-in-95 duration-300">
        {/* Header */}
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-2xl font-bold gradient-text">Request Swap</h2>
          <Button onClick={handleClose} variant="ghost" size="sm" className="text-gray-400 hover:text-white">
            <X className="w-5 h-5" />
          </Button>
        </div>

        {/* Item Info */}
        <div className="flex items-center space-x-4 mb-6 glass rounded-xl p-4">
          <img
            src={item.image || "/placeholder.svg"}
            alt={item.title}
            className="w-16 h-16 rounded-lg object-cover"
            style={{
              boxShadow: "0 0 10px rgba(16, 185, 129, 0.3)",
              border: "1px solid rgba(255, 255, 255, 0.2)",
            }}
          />
          <div>
            <h3 className="text-lg font-semibold text-white">{item.title}</h3>
            <p className="text-sm text-gray-400">by {item.user}</p>
          </div>
        </div>

        <form onSubmit={handleSubmit} className="space-y-6">
          {/* Message Field */}
          <div>
            <label className="block text-sm font-medium text-gray-300 mb-2">Why do you want this item?</label>
            <Textarea
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              placeholder="Tell the owner why you're interested in this item..."
              className="glass border-white/20 text-white placeholder-gray-400 focus:border-emerald-400 focus:neon-glow resize-none"
              rows={4}
              required
            />
          </div>

          {/* Actions */}
          <div className="flex space-x-4 pt-4">
            <Button
              type="button"
              onClick={handleClose}
              variant="outline"
              className="flex-1 border-gray-400 text-gray-400 hover:bg-gray-400 hover:text-gray-900"
              disabled={isSubmitting}
            >
              Cancel
            </Button>
            <Button
              type="submit"
              className="flex-1 eco-gradient text-white neon-glow hover:scale-105 transition-all duration-300 disabled:opacity-50 disabled:cursor-not-allowed"
              disabled={!message.trim() || isSubmitting}
            >
              {isSubmitting ? (
                <>
                  <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin mr-2" />
                  Sending...
                </>
              ) : (
                <>
                  <Send className="w-4 h-4 mr-2" />
                  Confirm Request
                </>
              )}
            </Button>
          </div>
        </form>
      </div>
    </div>
  )
}
