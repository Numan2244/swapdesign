"use client"

import type React from "react"

import { useState } from "react"
import { X, Camera, MapPin, User, Mail } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"

interface EditProfileModalProps {
  isOpen: boolean
  onClose: () => void
  userProfile: {
    name: string
    email: string
    bio: string
    location: string
    avatar: string
  }
  onSave: (profile: any) => void
}

export function EditProfileModal({ isOpen, onClose, userProfile, onSave }: EditProfileModalProps) {
  const [formData, setFormData] = useState(userProfile)
  const [avatarPreview, setAvatarPreview] = useState(userProfile.avatar)

  if (!isOpen) return null

  const handleInputChange = (field: string, value: string) => {
    setFormData((prev) => ({ ...prev, [field]: value }))
  }

  const handleAvatarChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (file) {
      const url = URL.createObjectURL(file)
      setAvatarPreview(url)
    }
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    onSave({ ...formData, avatar: avatarPreview })
    onClose()
  }

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      {/* Backdrop */}
      <div
        className="absolute inset-0 bg-black/60 backdrop-blur-sm animate-in fade-in duration-300"
        onClick={onClose}
      />

      {/* Modal */}
      <div className="relative glass-strong rounded-3xl p-8 max-w-md w-full max-h-[90vh] overflow-y-auto animate-in zoom-in-95 duration-300">
        {/* Header */}
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-2xl font-bold gradient-text">Edit Profile</h2>
          <Button onClick={onClose} variant="ghost" size="sm" className="text-gray-400 hover:text-white">
            <X className="w-5 h-5" />
          </Button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-6">
          {/* Avatar Upload */}
          <div className="text-center">
            <div className="relative inline-block">
              <div className="w-24 h-24 rounded-full bg-gradient-to-br from-emerald-400 to-blue-500 p-1">
                <div className="w-full h-full rounded-full bg-gray-800 flex items-center justify-center text-2xl overflow-hidden">
                  {avatarPreview ? (
                    <img
                      src={avatarPreview || "/placeholder.svg"}
                      alt="Avatar"
                      className="w-full h-full object-cover rounded-full"
                    />
                  ) : (
                    "👤"
                  )}
                </div>
              </div>
              <label className="absolute -bottom-2 -right-2 glass rounded-full p-2 cursor-pointer hover:neon-glow transition-all duration-300">
                <Camera className="w-4 h-4 text-emerald-400" />
                <input type="file" accept="image/*" onChange={handleAvatarChange} className="hidden" />
              </label>
            </div>
          </div>

          {/* Form Fields */}
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">
                <User className="w-4 h-4 inline mr-2" />
                Name
              </label>
              <Input
                value={formData.name}
                onChange={(e) => handleInputChange("name", e.target.value)}
                className="glass border-white/20 text-white placeholder-gray-400 focus:border-emerald-400 focus:neon-glow"
                placeholder="Your name"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">
                <Mail className="w-4 h-4 inline mr-2" />
                Email
              </label>
              <Input
                value={formData.email}
                onChange={(e) => handleInputChange("email", e.target.value)}
                type="email"
                className="glass border-white/20 text-white placeholder-gray-400 focus:border-emerald-400 focus:neon-glow"
                placeholder="your@email.com"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">
                <MapPin className="w-4 h-4 inline mr-2" />
                Location
              </label>
              <Input
                value={formData.location}
                onChange={(e) => handleInputChange("location", e.target.value)}
                className="glass border-white/20 text-white placeholder-gray-400 focus:border-emerald-400 focus:neon-glow"
                placeholder="Your location"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">Bio</label>
              <Textarea
                value={formData.bio}
                onChange={(e) => handleInputChange("bio", e.target.value)}
                className="glass border-white/20 text-white placeholder-gray-400 focus:border-emerald-400 focus:neon-glow resize-none"
                placeholder="Tell us about yourself..."
                rows={3}
              />
            </div>
          </div>

          {/* Actions */}
          <div className="flex space-x-4 pt-4">
            <Button
              type="button"
              onClick={onClose}
              variant="outline"
              className="flex-1 border-gray-400 text-gray-400 hover:bg-gray-400 hover:text-gray-900"
            >
              Cancel
            </Button>
            <Button
              type="submit"
              className="flex-1 eco-gradient text-white neon-glow hover:scale-105 transition-all duration-300"
            >
              Save Changes
            </Button>
          </div>
        </form>
      </div>
    </div>
  )
}
